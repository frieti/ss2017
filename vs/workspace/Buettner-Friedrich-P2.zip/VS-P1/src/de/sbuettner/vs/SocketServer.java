package de.sbuettner.vs;

// 05.04.16

/**
 *
 * @author Peter Altenberd (Translated into English by Ronald Moore)
 *         Computer Science Dept. Fachbereich Informatik Darmstadt Univ. of
 *         Applied Sciences Hochschule Darmstadt
 */

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class SocketServer extends Thread {
	DatagramSocket socket;
	Map<String, Integer> fuellstaende;
	private FileWriter fw;

	public void putFuellstaende(Map<String, Integer> fuellstaende) {
		this.fuellstaende = fuellstaende;
	}

	public void run(int port) throws IOException {
		System.out.println("Starting SocketServer Thread!");
		socket = new DatagramSocket(9004);
		fw = new FileWriter(new File("output.log"));

		while (true) {
			// Auf Anfrage warten

			DatagramPacket packet = new DatagramPacket(new byte[1024], 1024);
			socket.receive(packet);

			// Empfänger auslesen

			InetAddress address = packet.getAddress();
			int pport = packet.getPort();
			int len = packet.getLength();
			String line = new String(packet.getData(), "UTF-8");
			System.out.println(line);
			String[] split;
			split = line.split(":");
			if (split.length == 2 && split!=null) {
				//System.out.println("check");
				String key = split[0];
				int value = Integer.parseInt(split[1].trim());
				if (fuellstaende.containsKey(key)) {
					fuellstaende.remove(key);
					fuellstaende.put(key, value);
				} else {
					fuellstaende.put(key, value);
				}
			}
			SimpleDateFormat myDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// dd/MM/yyyy

			String logLine = myDate.format(new Date()) + " : " + (line) + " from: " + address + ":" + pport
					+ " of length " + len + "bytes!";

			fw.write(logLine + "\n");

			System.out.println(logLine);
		}

	}

	public void run() {
		try {
			run(9004);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
