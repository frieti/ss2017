package de.sbuettner.vs;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class http_server extends Thread{
	Map<String, Integer> fuellstaende;
	
	public void putFuellstaende(Map<String, Integer> fuellstaende) {
		this.fuellstaende = fuellstaende;
	}
	
	public void run() {
		ServerSocket server;
		try {
			server = new ServerSocket(9005);

			System.out.println("Listening for connection on port 9005 ....");
			while (true) {
				try (Socket socket = server.accept()) {
					//Date today = new Date();
                                        byte[] bytes = new byte[1024];
                                        socket.getInputStream().read(bytes);
                                        System.out.println(new String(bytes));
                                        
                                    /*try {
                                        Thread.sleep(5000);
                                    } catch (InterruptedException ex) {
                                        Logger.getLogger(http_server.class.getName()).log(Level.SEVERE, null, ex);
                                    }*/
					String httpResponse = "HTTP/1.1 200 OK\r\n";
					httpResponse += "Content-type: text/html\r\n\r\n";
					httpResponse += "<html><head><meta charset=\"utf-8\"/><title>Kühlschrank Tim Friedrich, Sebastian Büttner</title></head></body>";
					httpResponse += "<table><tr><th>Artikel</th><th>Füllstand(ml)</th></tr>";
					if (!fuellstaende.isEmpty()) {
						for (Entry<String, Integer> e : fuellstaende.entrySet()) {
							String Artikel = e.getKey();
							int ml = e.getValue();
							httpResponse += "<tr><td>" + Artikel + "</td><td>" + Integer.toString(ml) + "</td></tr>";
						}
					} else {
						httpResponse += "Keine Füllstände vorhanden!";
					}
					httpResponse += "</table>";
                                        
                                        Scanner sc = new Scanner(new File("output.log"));
                                        httpResponse += "<h2>History</h2>";

                                        while(sc.hasNextLine()) {
                                            String line = sc.nextLine();
                                            //System.out.println(line + " - next Line");
                                            if(line.indexOf("from")-2 > 0) {
                                                line = line.substring(0, line.indexOf("from")-2);
                                                //System.out.println(line + " - repaired Line");
                                                httpResponse+= "<p>" + line + "</p>";
                                                
                                            }
                                        }
                                        
                                        
					httpResponse += "</body></html>";
							
					socket.getOutputStream().write(httpResponse.getBytes("UTF-8"));
                                        
/*                                    try {
                                        Thread.sleep(1000);
                                    } catch (InterruptedException ex) {
                                        Logger.getLogger(http_server.class.getName()).log(Level.SEVERE, null, ex);
                                    }
        */
                                         socket.close();

                                        
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}