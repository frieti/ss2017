package de.sbuettner.vs.praktikum.junit;



public class SensorTester {

   
}
