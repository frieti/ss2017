package de.sbuettner.vs;

// 05.04.16

/**
 *
 * @author Peter Altenberd (Translated into English by Ronald Moore)
 *         Computer Science Dept. Fachbereich Informatik Darmstadt Univ. of
 *         Applied Sciences Hochschule Darmstadt
 */

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SocketServer extends Thread {
	DatagramSocket socket;
	public void run(int port) throws IOException {
		System.out.println("Starting SocketServer Thread!");
		/*ServerSocket contactSocket;
			contactSocket = new ServerSocket(port);		// original war Port 9999
			while (true) {								// Handle connection request
				Socket client = contactSocket.accept(); // create communication socket
				System.out.println("Connection with: " + client.getRemoteSocketAddress());
				new ClientHandler(client).start();
			}*/
		socket = new DatagramSocket( 9004 );
                
                FileWriter fw = new FileWriter(new File("output.log"));

		while (true) {
			// Auf Anfrage warten

			DatagramPacket packet = new DatagramPacket(new byte[1024], 1024);
			socket.receive(packet);

			// Empfänger auslesen

			InetAddress address = packet.getAddress();
			int pport = packet.getPort();
			int len = packet.getLength();
                        String line = new String(packet.getData(), "UTF-8");
                        System.out.println(line);
			SimpleDateFormat myDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
                        
                        String logLine = myDate.format(new Date()) + " : " + (line) + " from: " + address + ":" + pport + " of length " + len + "bytes!";
                        
                        fw.write(logLine +"\n");
                        
			System.out.println(logLine);
		}
                
	}
	
	public void run() {
		try {
			run(9004);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
