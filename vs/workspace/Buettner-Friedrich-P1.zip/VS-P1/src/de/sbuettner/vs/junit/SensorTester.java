package de.sbuettner.vs.junit;



public class SensorTester {

   
}
