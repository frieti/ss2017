#version 410

in vec3 fragmentColor;

out vec3 color;

void main(){
    color = fragmentColor;
}